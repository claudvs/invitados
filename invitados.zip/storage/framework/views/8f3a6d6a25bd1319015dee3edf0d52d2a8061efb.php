<?php if(Session::has('message')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <?php echo e(Session::get('message')); ?>

</div>
<?php endif; ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper" class="gray-bg">
<div class="row border-bottom">
  <nav class="navbar navbar-static-top  " role="navigation" style="margin-bottom: 0">
  <div class="navbar-header">
      <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>

  </div>
      <ul class="nav navbar-top-links navbar-right">
          <li>
              <span class="m-r-sm text-muted welcome-message">Bienvenido a INVITADOS Administrador.</span>
          </li>
          <li>
              <a href="login.html">
                  <i class="fa fa-sign-out"></i> Salir
              </a>
          </li>
      </ul>

  </nav>
</div>
    <div class="row wrapper border-bottom white-bg page-heading">
        <div class="col-sm-4">
            <h2>Relacionadores</h2>
            <ol class="breadcrumb">
                <li class="active">
                    <a href="#">Relacionadores</a>
                </li>

            </ol>
        </div>
    </div>

    <div class="wrapper wrapper-content">

      <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
          <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Relacionadores</h5>
                    </div>
                    <div class="ibox-content table-responsive">
                        <table class="table">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Nombre</th>
                                <th>Apellido</th>
                                <th>Relacionador</th>
                                <th>Email</th>
                                <th>Estado</th>
                                <th>Nro de celular</th>
                                <th>Opciones</th>
                            </tr>
                            </thead>
                            <?php foreach($misinvitados as $invitado): ?>
                            <tbody>
                            <tr>
                                <td><?php echo e($invitado->id); ?></td>
                                <td><?php echo e($invitado->name); ?></td>
                                <td><?php echo e($invitado->apellidos); ?></td>
                                <td><?php echo Auth::user()->name; ?></td>
                                <td><?php echo e($invitado->email); ?></td>
                                <?php if($invitado->estado == '1'): ?>
                                <td>Activo</td>
                                <?php endif; ?>
                                <?php if($invitado->estado == '0'): ?>
                                <td>Cancelado</td>
                                <?php endif; ?>
                                <td><?php echo e($invitado->nroCelular); ?></td>
                                <td>
                                  <?php echo link_to_route('invitado.show', $title = 'Ver', $parameters = $invitado->id, $attributes = ['class'=>'btn btn-info']); ?>

                                  <?php echo link_to_route('invitado.edit', $title = 'Editar', $parameters = $invitado->id, $attributes = ['class'=>'btn btn-info']); ?>


                                </td>
                            </tr>
                            </tbody>
                            <?php endforeach; ?>
                        </table>

                    </div>
                </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>