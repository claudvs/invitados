
Hola
<img src="<?php echo $message->embed($qrFile); ?>">
