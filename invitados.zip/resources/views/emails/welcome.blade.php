
Hola
<img src="{!!$message->embed($qrFile)!!}">
