<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>
        <?php echo Html::style('css/bootstrap.min.css'); ?>

        <?php echo Html::style('css/bootstrap-datetimepicker.css'); ?>

        <?php echo Html::style('font-awesome/css/font-awesome.css'); ?>

        <?php echo Html::style('css/plugins/chosen.css'); ?>

        <?php echo Html::style('css/plugins/datepicker3.css'); ?>

        <?php echo Html::style('css/plugins/clockpicker.css'); ?>

        <?php echo Html::style('css/plugins/daterangepicker-bs3.css'); ?>

        <?php echo Html::style('css/plugins/select2.min.css'); ?>

        <?php echo Html::style('css/animate.css'); ?>


    </head>
    <body>
      <?php if(Session::has('message')): ?>
      <div class="alert alert-danger alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <?php echo e(Session::get('message')); ?>

      </div>
      <?php endif; ?>
        <div class="container">
            <?php echo $__env->make('alerts.request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <h1>Bienvenido <?php echo Auth::user()->name; ?></h1>
              <?php echo Form::open(['route'=>'invitado.store','method'=>'POST']); ?>

              <div class="form-group">
                <div class="col-md-6">
                  <label>Nombre del Usuario</label>
                  <?php echo Form::text('name',Auth::user()->name,['class'=>'form-control','placeholder'=>'Ingrese el Nombre de la persona']); ?>

                </div>
                <div class="col-md-6">
                  <label>Apellido</label>
                  <?php echo Form::text('apellidos',Auth::user()->apellidos,['class'=>'form-control','placeholder'=>'Ingrese el Apellido de la persona']); ?>

                </div>
                <div class="col-md-6">
                  <label>Nro de celular</label>
                  <?php echo Form::text('nroCelular',Auth::user()->nroCelular,['class'=>'form-control','placeholder'=>'Ingrese el numero de celular']); ?>

                </div>
                <div class="col-md-6">
                  <label>Fecha del Nacimiento</label>
                  <div class='input-group date'>
                      <?php echo Form::text('fechanac',Auth::user()->fechanac,['class'=>'form-control','id'=>'daterelacionadores','placeholder'=>'Fecha de nacimiento']); ?>

                      <span class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </span>
                    </div>
                </div>
                <div class="col-md-6">
                  <label>Correo Electronico</label>
                  <?php echo Form::email('email',Auth::user()->email,['class'=>'form-control','placeholder'=>'Ingrese el correo electronico de la persona']); ?>

                </div>
                <div class="col-md-12">
                  <label>Sexo</label>
                  <?php echo Form::select('sexo', array('Masculino' => 'Masculino', 'Femenino' => 'Femenino'), Auth::user()->sexo, ['class'=>'form-control','placeholder' => 'Sexo']); ?>

                </div>
                <div class="col-md-12">
                  <label>Codigo Relacionador</label>
                  <?php echo Form::text('codigo',null,['class'=>'form-control','placeholder'=>'Ingrese el codigo de relacionador']); ?>

                </div>
                <div class="col-md-12">
                    <br>
                    <?php echo Form::submit('Registrar',['class'=>'btn btn-info']); ?>

                </div>
              <?php echo Form::close(); ?>

        </div>
      </div>


        <?php echo Html::script('js/jquery-2.1.1.js'); ?>

        <?php echo Html::script('js/bootstrap.min.js'); ?>

        <?php echo Html::script('js/inspinia.js'); ?>

        <?php echo Html::script('js/plugins/pace/pace.min.js'); ?>

        <?php echo Html::script('js/plugins/slimscroll/jquery.slimscroll.min.js'); ?>

        <?php echo Html::script('js/chosen.jquery.js'); ?>

        <?php echo Html::script('js/jquery.knob.js'); ?>

        <?php echo Html::script('js/jasny-bootstrap.min.js'); ?>

        <?php echo Html::script('js/jquery.steps.min.js'); ?>

        <?php echo Html::script('js/jquery.validate.min.js'); ?>




        <?php echo Html::script('js/moment.js'); ?>

        <?php echo Html::script('js/bootstrap-datetimepicker.js'); ?>

        <?php echo Html::script('js/jquery.nouislider.min.js'); ?>

        <?php echo Html::script('js/switchery.js'); ?>

        <?php echo Html::script('js/ion.rangeSlider.min.js'); ?>

        <?php echo Html::script('js/icheck.min.js'); ?>

        <?php echo Html::script('js/plugins/metisMenu/jquery.metisMenu.js'); ?>

        <?php echo Html::script('js/bootstrap-colorpicker.min.js'); ?>

        <?php echo Html::script('js/plugins/clockpicker.js'); ?>

        <?php echo Html::script('js/cropper.min.js'); ?>

        <?php echo Html::script('js/moment.min.js'); ?>

        <?php echo Html::script('js/plugins/daterangepicker.js'); ?>

        <?php echo Html::script('js/plugins/select2.full.min.js'); ?>


        <?php echo Html::script('js/jquery.bootstrap-touchspin.min.js'); ?>


        <!-- Flot -->
        <?php echo Html::script('js/plugins/flot/jquery.flot.js'); ?>

        <?php echo Html::script('js/plugins/flot/jquery.flot.tooltip.min.js'); ?>

        <?php echo Html::script('js/plugins/flot/jquery.flot.spline.js'); ?>

        <?php echo Html::script('js/plugins/flot/jquery.flot.resize.js'); ?>

        <?php echo Html::script('js/plugins/flot/jquery.flot.pie.js'); ?>


        <!-- Peity -->
        <?php echo Html::script('js/plugins/peity/jquery.peity.min.js'); ?>

        <?php echo Html::script('js/demo/peity-demo.js'); ?>


        <!-- Custom and plugin javascript -->

        <?php echo Html::script('js/plugins/pace/pace.min.js'); ?>


        <!-- jQuery UI -->
        <?php echo Html::script('js/plugins/jquery-ui/jquery-ui.min.js'); ?>



        <!-- GITTER -->
        <?php echo Html::script('js/plugins/gritter/jquery.gritter.min.js'); ?>



        <!-- Sparkline -->
        <?php echo Html::script('js/plugins/sparkline/jquery.sparkline.min.js'); ?>



        <!-- Sparkline demo data  -->
        <?php echo Html::script('js/demo/sparkline-demo.js'); ?>



        <!-- ChartJS-->
        <?php echo Html::script('js/plugins/chartJs/Chart.min.js'); ?>



        <!-- Toastr -->
        <?php echo Html::script('js/plugins/toastr/toastr.min.js'); ?>

        <script>
          $(document).ready(function(){

            $('#daterelacionadores').datetimepicker();
            $('.clockpicker').clockpicker();

          $(".touchspin3").TouchSpin({
              verticalbuttons: true,
              buttondown_class: 'btn btn-white',
              buttonup_class: 'btn btn-white'
            });
          });
        </script>
    </body>
</html>
