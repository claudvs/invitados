<?php

namespace invitados;

use Illuminate\Database\Eloquent\Model;

class Relacion_evento_relacionador extends Model
{
    protected $table = 'relacion_evento_relacionadors';
}
