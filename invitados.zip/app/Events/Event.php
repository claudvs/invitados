<?php

namespace invitados\Events;

abstract class Event
{
    //
}
